package com.zerotrace.messenger.bridge

import com.zerotrace.messenger.network.TorState

/**
 * JNI bridge to libzerotrace_core.so (Rust).
 *
 * Design rules enforced here:
 * - Session handles are opaque Long ids. Private keys never cross this boundary.
 * - The only plaintext that crosses is the active session's message bytes, held in
 *   short-lived byte arrays that the caller clears. See docs/CRYPTOGRAPHIC_PROTOCOL.md
 *   section "FFI boundary" for the unavoidable copies.
 * - If the native library is absent (e.g. a build without the Rust core), every call
 *   fails closed: [available] is false and the UI must show the core as unavailable,
 *   never pretend encryption is active.
 */
object RustCoreBridge {
    val available: Boolean

    init {
        var loaded = false
        try {
            System.loadLibrary("zerotrace_core")
            loaded = true
        } catch (e: UnsatisfiedLinkError) {
            loaded = false
        }
        available = loaded
    }

    // Identity (all byte arrays are raw public/secret material; secret material is only
    // ever handed to KeystoreManager for wrapping, never to a Composable).
    external fun nativeGenerateIdentity(): ByteArray // serialised IdentityBundle, see rust ffi.rs
    external fun nativeIdentityFingerprint(identityBundle: ByteArray): String
    external fun nativeCreatePairingQr(identityBundle: ByteArray, onionAddress: String): String
    external fun nativeVerifyPairingQr(qrJson: String): String // commitment fingerprint, or throws
    external fun nativeBundleJson(identityBundle: ByteArray, onionAddress: String): String
    external fun nativeVerifyBundle(bundleJson: String, qrJson: String): ByteArray // verified full identity
    external fun nativeBundleSend(onionAddress: String, frameType: Int, data: ByteArray): Boolean
    external fun nativeBundlePoll(): ByteArray? // null when nothing arrived

    // Sessions: opaque handle. 0 means invalid.
    external fun nativeOpenSession(identityBundle: ByteArray, peerBundle: ByteArray): Long
    external fun nativeHandshakeInit(handle: Long): ByteArray
    external fun nativeHandshakeRespond(handle: Long, initMsg: ByteArray): ByteArray
    external fun nativeHandshakeFinish(handle: Long, responseMsg: ByteArray): Boolean
    /** Accepts an incoming Init. Returns 8-byte LE handle || response bytes. */
    external fun nativeAcceptHandshake(identityBundle: ByteArray, initMsg: ByteArray): ByteArray
    /** Initiator side: which onion a session handle talks to. */
    external fun nativeBindPeer(handle: Long, onionAddress: String)
    /** Responder side: route an accepted stream (by initiator Ed25519 hex) to a handle. */
    external fun nativeBindIncoming(edPkHex: String, handle: Long)
    external fun nativeEncrypt(handle: Long, plaintext: ByteArray): ByteArray
    external fun nativeDecrypt(handle: Long, ciphertext: ByteArray): ByteArray
    external fun nativeCloseSession(handle: Long)
    external fun nativeSessionInfo(handle: Long): String // JSON: counters, ratchet state
    external fun nativeSelfTest(): String // "OK" or a failure description

    // Transport is owned by the Rust core (Arti onion stream). Kotlin never opens a
    // socket itself, so there is no clearnet path in the app layer at all.
    external fun nativeTransportSend(handle: Long, ciphertext: ByteArray): Boolean
    external fun nativeTransportPoll(handle: Long): ByteArray? // null when nothing arrived

    // Tor (Arti). Returns the current state name; the Rust side owns the client.
    // stateDir is the app-private Arti directory (filesDir/arti).
    external fun nativeTorStart(stateDir: String): String
    external fun nativeTorState(): String
    external fun nativeOnionAddress(): String
    external fun nativeTorStop()

    // Calls (v0.3.0, Tor-native voice). The media key crosses JNI exactly once
    // per direction (see rust ffi.rs); it is never stored by Kotlin and is
    // zeroed in the Rust registry on call end.
    /** Caller side: returns 48 bytes, callId(16) || media key(32). */
    external fun nativeCallBegin(): ByteArray
    /** Callee side: register the call the peer invited us to. */
    external fun nativeCallJoin(callId: ByteArray, mediaKey: ByteArray): Boolean
    external fun nativeCallEnd(callId: ByteArray)
    /** Callee side: connect to the caller's onion service for this call. */
    external fun nativeCallConnect(callId: ByteArray, onionAddress: String): Boolean
    external fun nativeCallSendAudio(callId: ByteArray, opusFrame: ByteArray): Boolean
    /** One decrypted Opus frame, or null when nothing arrived. */
    external fun nativeCallPollAudio(callId: ByteArray): ByteArray?
    /** One call event JSON, or null: {"event":"connected"|"disconnected"|"connect-failed","callId":"<hex>"}. */
    external fun nativeCallPollEvent(): String?
    external fun nativeCallIsConnected(callId: ByteArray): Boolean

    /** Onion-stream frame types (must match rust-core/src/tor.rs). */
    const val FRAME_BUNDLE: Int = 66 // 'B'
    const val FRAME_INIT: Int = 73 // 'I'
    const val FRAME_RESPONSE: Int = 82 // 'R'

    fun torState(): TorState = try {
        TorState.valueOf(nativeTorState())
    } catch (e: Exception) {
        TorState.ERROR
    }
}
