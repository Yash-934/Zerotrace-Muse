package com.zerotrace.messenger.security

import android.app.Activity
import android.view.WindowManager

/** FLAG_SECURE on every screen that can show identity material or chat content. */
object SecureWindowManager {
    fun apply(activity: Activity) {
        activity.window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}
